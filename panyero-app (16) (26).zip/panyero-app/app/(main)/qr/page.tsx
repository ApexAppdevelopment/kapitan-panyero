'use client'

import { ArrowLeft } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

export default function QRPage() {
  return (
    <div className="min-h-screen bg-[#E8F5E9]">
      {/* Header */}
      <div className="flex items-center p-4 gap-4">
        <Link href="/" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-medium">My QR</h1>
      </div>

      {/* QR Card */}
      <div className="mx-4 bg-white rounded-3xl p-6">
        <div className="flex flex-col items-center gap-6">
          {/* Avatar */}
          <div className="w-20 h-20 bg-[#00A651] rounded-full flex items-center justify-center">
            <span className="text-3xl text-white font-medium">m</span>
          </div>

          {/* User Info */}
          <div className="text-center">
            <h2 className="text-2xl font-medium">KIM LOUZEL OMADTO</h2>
            <p className="text-gray-500">+63 *** *** 6758</p>
          </div>

          {/* QR Code */}
          <div className="w-full max-w-xs relative">
            <Image
              src="/placeholder.svg?height=300&width=300"
              alt="QR Code"
              width={300}
              height={300}
              className="w-full h-auto"
            />
            {/* InstaPay Logo Overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-white p-2 rounded-lg">
                <Image
                  src="/placeholder.svg?height=40&width=80"
                  alt="InstaPay"
                  width={80}
                  height={40}
                  className="w-20 h-auto"
                />
              </div>
            </div>
          </div>

          {/* Notice */}
          <p className="text-sm text-gray-500">Transfer fees may apply</p>

          {/* Panyero Logo */}
          <Image
            src="https://panyero.website/wallet-app/assets/logo-light.png"
            alt="Panyero"
            width={120}
            height={40}
            className="w-32 h-auto"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-4 space-y-3">
        <button className="w-full py-4 rounded-full bg-black text-white font-medium text-lg">
          Generate Custom QR Code
        </button>
        <button className="w-full py-4 rounded-full bg-[#E8F5E9] text-[#00A651] font-medium text-lg border-2 border-[#00A651]">
          Share/Save
        </button>
      </div>
    </div>
  )
}

