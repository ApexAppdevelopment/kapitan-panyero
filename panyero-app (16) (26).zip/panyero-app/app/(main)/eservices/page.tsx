'use client'

import { useState } from 'react'
import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import EServicesContent from '../../components/EServicesContent'
import AIServices from '../../components/AIServices'
import BettingAndGaming from '../../components/BettingAndGaming'
import { Search } from 'lucide-react'

export default function EServices() {
  const [searchTerm, setSearchTerm] = useState('')

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] pb-24">
      <Header userLevel={5} searchTerm={searchTerm} setSearchTerm={setSearchTerm}/>
      <div className="px-4 space-y-6">
        <h1 className="text-2xl font-bold text-[#1a237e]">E-Services</h1>
        <AIServices />
        <BettingAndGaming />
        <EServicesContent searchTerm={searchTerm} />
      </div>
      <NavigationBar />
    </div>
  )
}

