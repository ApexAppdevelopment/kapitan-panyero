import Header from '../../components/Header'
import NavigationBar from '../../components/NavigationBar'
import UserProfile from '../../components/UserProfile'

export default function Profile() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef] p-4 pb-24">
      <Header userLevel={5} />
      <UserProfile />
      <NavigationBar />
    </div>
  )
}

