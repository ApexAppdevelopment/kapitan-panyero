import SendMoney from '../../components/SendMoney'

export default function SendPage() {
  return <SendMoney />
}

