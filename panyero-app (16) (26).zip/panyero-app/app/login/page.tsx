'use client'

import { useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import Image from 'next/image'

export default function Login() {
  const router = useRouter()
  const { signIn } = useAuth()
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.email || !formData.password) {
      setError('Please fill in all fields')
      return
    }

    try {
      setError('')
      setLoading(true)
      await signIn(formData.email, formData.password)
      router.push('/dashboard')
    } catch (error) {
      setError('Failed to sign in')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="flex justify-center mb-12">
        <Image
          src="https://panyero.website/wallet-app/assets/logo-light.png"
          alt="Panyero Logo"
          width={300}
          height={60}
          className="h-16 w-auto"
        />
      </div>

      <h1 className="text-3xl font-medium mb-8 text-center">Log In</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-[#00A651] mb-1">Email</label>
          <input
            type="email"
            placeholder="Your email address"
            className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            required
          />
        </div>

        <div>
          <label className="block text-[#00A651] mb-1">Password</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter password"
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5 text-gray-400" />
              ) : (
                <Eye className="w-5 h-5 text-gray-400" />
              )}
            </button>
          </div>
        </div>

        {error && (
          <p className="text-red-500 text-sm text-center">{error}</p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full p-4 rounded-xl bg-[#00A651] text-white font-medium hover:bg-[#008c44] transition-colors disabled:opacity-50"
        >
          {loading ? 'Signing in...' : 'Log In'}
        </button>

        <p className="text-center">
          Don't have an account?{' '}
          <Link href="/" className="text-[#00A651] hover:underline">
            Sign up
          </Link>
        </p>
      </form>
    </div>
  )
}

