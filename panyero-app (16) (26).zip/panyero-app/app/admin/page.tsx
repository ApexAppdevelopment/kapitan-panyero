'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { collection, getDocs, query, orderBy, limit, doc, setDoc, getDoc } from 'firebase/firestore'
import { db } from '@/firebase'

interface Service {
  id: string
  name: string
  url: string
  iconUrl: string
}

interface User {
  id: string
  name: string
  email: string
  balance: number
}

interface Transaction {
  id: string
  userId: string
  type: 'in' | 'out'
  amount: number
  timestamp: Date
}

interface CashRequest {
  id: string
  userId: string
  type: 'in' | 'out'
  amount: number
  status: 'pending' | 'approved' | 'rejected'
  timestamp: Date
}

interface AffiliateRewards {
  level1: number
  level2: number
  level3: number
  level4: number
  level5: number
}

export default function AdminDashboard() {
  const [services, setServices] = useState<Service[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [cashRequests, setCashRequests] = useState<CashRequest[]>([])
  const [newService, setNewService] = useState({ name: '', url: '', iconUrl: '' })
  const [editingService, setEditingService] = useState<Service | null>(null)
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage] = useState(10)
  const [affiliateRewards, setAffiliateRewards] = useState<AffiliateRewards>({
    level1: 0,
    level2: 0,
    level3: 0,
    level4: 0,
    level5: 0
  })
  const [isUpdatingRewards, setIsUpdatingRewards] = useState(false)

  useEffect(() => {
    fetchServices()
    fetchUsers()
    fetchTransactions()
    fetchCashRequests()
    fetchAffiliateRewards()
  }, [])

  const fetchServices = async () => {
    try {
      const response = await fetch('https://panyero.website/wallet-app/knowledge-panyeroapp.json')
      const data = await response.json()
      const serviceList = Object.entries(data).map(([key, value]: [string, any]) => ({
        id: key,
        name: value.title.slice(0, 6),
        url: value.url || 'https://panyero.website/movie',
        iconUrl: value.icon.startsWith('http') ? value.icon : `https://panyero.website/wallet-app/assets/${value.icon}`
      }))
      setServices(serviceList)
    } catch (error) {
      console.error('Error fetching services:', error)
    }
  }

  const fetchUsers = async () => {
    const usersCollection = collection(db, 'users')
    const userSnapshot = await getDocs(usersCollection)
    const userList = userSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User))
    setUsers(userList)
  }

  const fetchTransactions = async () => {
    const transactionsCollection = collection(db, 'transactions')
    const q = query(transactionsCollection, orderBy('timestamp', 'desc'), limit(itemsPerPage))
    const transactionSnapshot = await getDocs(q)
    const transactionList = transactionSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction))
    setTransactions(transactionList)
  }

  const fetchCashRequests = async () => {
    const cashRequestsCollection = collection(db, 'cashRequests')
    const q = query(cashRequestsCollection, orderBy('timestamp', 'desc'), limit(itemsPerPage))
    const cashRequestSnapshot = await getDocs(q)
    const cashRequestList = cashRequestSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashRequest))
    setCashRequests(cashRequestList)
  }

  const fetchAffiliateRewards = async () => {
    try {
      const rewardsDoc = await getDoc(doc(db, 'settings', 'affiliateRewards'))
      if (rewardsDoc.exists()) {
        setAffiliateRewards(rewardsDoc.data() as AffiliateRewards)
      }
    } catch (error) {
      console.error('Error fetching affiliate rewards:', error)
    }
  }

  const handleAddService = async (e: React.FormEvent) => {
    e.preventDefault()
    if (newService.name && newService.iconUrl) {
      const newId = Date.now().toString()
      setServices([...services, { id: newId, ...newService }])
      setNewService({ name: '', url: '', iconUrl: '' })
    }
  }

  const handleEditService = async (service: Service) => {
    setServices(services.map(s => s.id === service.id ? service : s))
    setEditingServiceId(null)
  }

  const handleCancelEdit = () => {
    setEditingServiceId(null)
  }

  const handleDeleteService = async (id: string) => {
    setServices(services.filter(service => service.id !== id))
  }

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage)
    // Implement pagination logic here for users, transactions, and cash requests
  }

  const handleUpdateAffiliateRewards = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsUpdatingRewards(true)
    try {
      await setDoc(doc(db, 'settings', 'affiliateRewards'), affiliateRewards)
      alert('Affiliate rewards updated successfully!')
    } catch (error) {
      console.error('Error updating affiliate rewards:', error)
      alert('Failed to update affiliate rewards. Please try again.')
    } finally {
      setIsUpdatingRewards(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] p-4">
      <div className="flex items-center mb-8">
        <Link href="/profile" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-bold ml-2">Admin Dashboard</h1>
      </div>

      {/* Services Section */}
      <div className="bg-white rounded-xl p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Manage Services</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {services.map((service) => (
            <div
              key={service.id}
              className="relative p-4 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              onMouseEnter={() => setEditingServiceId(service.id)}
              onMouseLeave={() => setEditingServiceId(null)}
            >
              <img src={service.iconUrl} alt={service.name} className="w-12 h-12 mx-auto mb-2" />
              <p className="text-center font-medium">{service.name}</p>
              {editingServiceId === service.id && (
                <div className="absolute inset-0 bg-white bg-opacity-90 p-2 flex flex-col justify-center">
                  <input
                    type="text"
                    value={service.url}
                    onChange={(e) => handleEditService({ ...service, url: e.target.value })}
                    className="mb-2 p-1 border rounded"
                  />
                  <div className="flex justify-between">
                    <button
                      onClick={() => handleEditService(service)}
                      className="px-2 py-1 bg-green-500 text-white rounded text-sm"
                    >
                      Save
                    </button>
                    <button
                      onClick={handleCancelEdit}
                      className="px-2 py-1 bg-red-500 text-white rounded text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        {/* Add new service form */}
        <form onSubmit={handleAddService} className="mt-4">
          <input
            type="text"
            placeholder="Service Name"
            value={newService.name}
            onChange={(e) => setNewService({ ...newService, name: e.target.value })}
            className="mr-2 p-2 border rounded"
          />
          <input
            type="text"
            placeholder="Service URL"
            value={newService.url}
            onChange={(e) => setNewService({ ...newService, url: e.target.value })}
            className="mr-2 p-2 border rounded"
          />
          <input
            type="text"
            placeholder="Icon URL"
            value={newService.iconUrl}
            onChange={(e) => setNewService({ ...newService, iconUrl: e.target.value })}
            className="mr-2 p-2 border rounded"
          />
          <button type="submit" className="p-2 bg-blue-500 text-white rounded">
            Add Service
          </button>
        </form>
      </div>

      {/* Affiliate Rewards Section */}
      <div className="bg-white rounded-xl p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Affiliate Rewards</h2>
        <form onSubmit={handleUpdateAffiliateRewards} className="space-y-4">
          {Object.keys(affiliateRewards).map((level, index) => (
            <div key={level} className="flex items-center">
              <label htmlFor={level} className="w-24">Level {index + 1}:</label>
              <input
                type="number"
                id={level}
                value={affiliateRewards[level as keyof AffiliateRewards]}
                onChange={(e) => setAffiliateRewards({
                  ...affiliateRewards,
                  [level]: parseFloat(e.target.value)
                })}
                className="w-full p-2 border rounded"
                min="0"
                step="0.01"
                required
              />
            </div>
          ))}
          <button
            type="submit"
            className="w-full p-2 bg-[#00A651] text-white rounded"
            disabled={isUpdatingRewards}
          >
            {isUpdatingRewards ? 'Updating...' : 'Update Affiliate Rewards'}
          </button>
        </form>
      </div>

      {/* Users Section */}
      <div className="bg-white rounded-xl p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Users</h2>
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Email</th>
              <th className="px-4 py-2">Balance</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td className="border px-4 py-2">{user.name}</td>
                <td className="border px-4 py-2">{user.email}</td>
                <td className="border px-4 py-2">{user.balance}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Transactions Section */}
      <div className="bg-white rounded-xl p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Transactions</h2>
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="px-4 py-2">User ID</th>
              <th className="px-4 py-2">Type</th>
              <th className="px-4 py-2">Amount</th>
              <th className="px-4 py-2">Date</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map(transaction => (
              <tr key={transaction.id}>
                <td className="border px-4 py-2">{transaction.userId}</td>
                <td className="border px-4 py-2">{transaction.type}</td>
                <td className="border px-4 py-2">{transaction.amount}</td>
                <td className="border px-4 py-2">{transaction.timestamp.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Cash Requests Section */}
      <div className="bg-white rounded-xl p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Cash In/Out Requests</h2>
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="px-4 py-2">User ID</th>
              <th className="px-4 py-2">Type</th>
              <th className="px-4 py-2">Amount</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2">Date</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {cashRequests.map(request => (
              <tr key={request.id}>
                <td className="border px-4 py-2">{request.userId}</td>
                <td className="border px-4 py-2">{request.type}</td>
                <td className="border px-4 py-2">{request.amount}</td>
                <td className="border px-4 py-2">{request.status}</td>
                <td className="border px-4 py-2">{request.timestamp.toLocaleString()}</td>
                <td className="border px-4 py-2">
                  {request.status === 'pending' && (
                    <>
                      <button className="bg-green-500 text-white px-2 py-1 rounded mr-2">Approve</button>
                      <button className="bg-red-500 text-white px-2 py-1 rounded">Reject</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-4">
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="mx-1 px-3 py-1 bg-gray-200 rounded"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <span className="mx-2">{currentPage}</span>
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          className="mx-1 px-3 py-1 bg-gray-200 rounded"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}

