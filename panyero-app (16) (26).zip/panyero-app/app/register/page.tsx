'use client'

import { useState } from 'react'
import { ArrowLeft, Eye, EyeOff } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import Image from 'next/image'

export default function Register() {
  const router = useRouter()
  const { signUp } = useAuth()
  const [formData, setFormData] = useState({
    phoneNumber: '',
    password: '',
    confirmPassword: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.phoneNumber || !formData.password || !formData.confirmPassword) {
      setError('Please fill in all fields')
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match')
      return
    }

    try {
      setError('')
      setLoading(true)
      await signUp(formData.phoneNumber, formData.password)
      router.push('/')
    } catch (error) {
      setError('Failed to create an account')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="flex items-center mb-8">
        <Link href="/" className="p-2">
          <ArrowLeft className="w-6 h-6" />
        </Link>
      </div>

      <div className="flex justify-center mb-12">
        <Image
          src="https://panyero.website/wallet-app/assets/logo-light.png"
          alt="Panyero Logo"
          width={200}
          height={40}
          className="h-10 w-auto"
        />
      </div>

      <h1 className="text-3xl font-medium mb-8 text-center">Create an Account</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex gap-2">
          <div className="w-16">
            <input
              type="text"
              value="+63"
              disabled
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 text-center text-gray-600"
            />
          </div>
          <div className="flex-1">
            <input
              type="tel"
              placeholder="9056741316"
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
              value={formData.phoneNumber}
              onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-[#00A651] mb-1">Password</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter password"
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5 text-gray-400" />
              ) : (
                <Eye className="w-5 h-5 text-gray-400" />
              )}
            </button>
          </div>
        </div>

        <div>
          <label className="block text-[#00A651] mb-1">Confirm Password</label>
          <div className="relative">
            <input
              type={showConfirmPassword ? 'text' : 'password'}
              placeholder="Confirm password"
              className="w-full p-4 rounded-xl bg-gray-50/80 border-0 placeholder:text-gray-400 focus:ring-0"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2"
            >
              {showConfirmPassword ? (
                <EyeOff className="w-5 h-5 text-gray-400" />
              ) : (
                <Eye className="w-5 h-5 text-gray-400" />
              )}
            </button>
          </div>
        </div>

        {error && (
          <p className="text-red-500 text-sm text-center">{error}</p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full p-4 rounded-xl bg-[#00A651] text-white font-medium hover:bg-[#008c44] transition-colors disabled:opacity-50"
        >
          {loading ? 'Creating account...' : 'Sign Up'}
        </button>

        <p className="text-center">
          Already have an account?{' '}
          <Link href="/login" className="text-[#00A651] hover:underline">
            Log in
          </Link>
        </p>
      </form>
    </div>
  )
}

