import { FC } from 'react'
import { Book, Hotel, Ship, CloudSun, MapPin, Gift, LifeBuoy, Settings } from 'lucide-react'

const quickAccessItems = [
  { icon: Book, label: 'Review', section: 'review' },
  { icon: Hotel, label: 'Booking', section: 'booking' },
  { icon: Ship, label: 'Ship Info', section: 'shipInfo' },
  { icon: CloudSun, label: 'Weather', section: 'weather' },
  { icon: MapPin, label: 'GPS', section: 'gps' },
  { icon: Gift, label: 'Rewards', section: 'rewards' },
  { icon: LifeBuoy, label: 'Help', section: 'help' },
  { icon: Settings, label: 'Settings', section: 'settings' },
]

const QuickAccess: FC = () => {
  return (
    <div className="bg-white p-4 rounded-xl shadow-md hover:shadow-lg transition-shadow mb-6">
      <h3 className="font-roboto font-semibold mb-4 text-[#1a237e]">Quick Access</h3>
      <div className="grid grid-cols-4 gap-4">
        {quickAccessItems.map((item, index) => (
          <div
            key={index}
            className="text-center cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition-colors"
          >
            <div className="bg-[#f8f9fa] p-3 rounded-lg mb-2">
              <item.icon className="text-xl text-[#1a237e] mx-auto" />
            </div>
            <p className="text-xs">{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default QuickAccess

