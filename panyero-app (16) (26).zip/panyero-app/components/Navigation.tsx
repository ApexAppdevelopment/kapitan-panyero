'use client'

import { useState } from 'react'
import { Home, CreditCard, QrCode, Ship, User } from 'lucide-react'

export default function Navigation() {
  const [activePage, setActivePage] = useState('home')

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-lg p-4 hover:bg-gray-100 transition-colors">
      <div className="flex justify-around items-center">
        <NavItem icon={<Home />} page="home" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={<CreditCard />} page="eservices" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={<QrCode />} page="scan" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={<Ship />} page="maritime" activePage={activePage} setActivePage={setActivePage} />
        <NavItem icon={<User />} page="profile" activePage={activePage} setActivePage={setActivePage} />
      </div>
    </nav>
  )
}

function NavItem({ icon, page, activePage, setActivePage }: { icon: React.ReactNode, page: string, activePage: string, setActivePage: (page: string) => void }) {
  return (
    <div
      className={`text-center cursor-pointer transform transition-transform hover:-translate-y-1 ${page === 'scan' ? '-mt-6' : ''}`}
      onClick={() => setActivePage(page)}
    >
      <div className={`${page === 'scan' ? 'bg-white rounded-full p-4 shadow-lg hover:shadow-xl transition-shadow' : ''}`}>
        {React.cloneElement(icon as React.ReactElement, {
          className: `${activePage === page ? 'text-[#1a237e]' : 'text-gray-500'} hover:text-blue-600 transition-colors ${page === 'scan' ? 'text-2xl' : 'text-xl'}`
        })}
      </div>
    </div>
  )
}

