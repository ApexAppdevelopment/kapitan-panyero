import { useState, FC } from 'react'
import { db } from '../firebase'
import { collection, addDoc, serverTimestamp, updateDoc, doc, increment } from 'firebase/firestore'
import { Wallet, Building, Users, CreditCard, Smartphone } from 'lucide-react'

interface CashInModalProps {
  onClose: () => void
  onBalanceChange: (newBalance: number) => void
}

interface PaymentOption {
  id: string
  name: string
  icon: React.ElementType
}

interface CommunitySeller {
  id: string
  name: string
  panyeroTokens: number
}

const paymentOptions: Record<string, PaymentOption[]> = {
  eWallet: [
    { id: 'gcash', name: 'GCash', icon: Smartphone },
    { id: 'paymaya', name: 'PayMaya', icon: Smartphone },
  ],
  bank: [
    { id: 'bpi', name: 'BPI', icon: Building },
    { id: 'bdo', name: 'BDO', icon: Building },
  ],
}

const communitySellers: CommunitySeller[] = [
  { id: 'seller1', name: 'Juan Dela Cruz', panyeroTokens: 1000 },
  { id: 'seller2', name: 'Maria Santos', panyeroTokens: 750 },
  { id: 'seller3', name: 'Pedro Reyes', panyeroTokens: 500 },
]

const CashInModal: FC<CashInModalProps> = ({ onClose, onBalanceChange }) => {
  const [amount, setAmount] = useState<number | ''>('')
  const [paymentCategory, setPaymentCategory] = useState<string | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null)
  const [selectedSeller, setSelectedSeller] = useState<CommunitySeller | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleCashIn = async () => {
    if (amount === '' || !paymentMethod) return

    try {
      const paymentTitle = selectedSeller 
        ? `Bought Panyero Tokens from ${selectedSeller.name}`
        : `Cash In via ${paymentMethod}`

      // Add transaction to Firestore
      await addDoc(collection(db, 'transactions'), {
        type: 'receive',
        amount: parseFloat(amount.toString()),
        title: paymentTitle,
        timestamp: serverTimestamp(),
      })

      // Update user's balance in Firestore
      const userRef = doc(db, 'users', 'currentUserId') // Replace 'currentUserId' with actual user ID
      await updateDoc(userRef, {
        balance: increment(parseFloat(amount.toString()))
      })

      onBalanceChange((prevBalance) => prevBalance + parseFloat(amount.toString()))
      onClose()
    } catch (error) {
      console.error('Error cashing in:', error)
      setError('Failed to cash in. Please try again.')
    }
  }

  const renderPaymentOptions = () => {
    if (!paymentCategory) return null

    if (paymentCategory === 'communitySeller') {
      return (
        <div className="grid grid-cols-1 gap-2">
          {communitySellers.map((seller) => (
            <button
              key={seller.id}
              className={`p-3 border rounded-lg flex items-center justify-between hover:bg-gray-100 transition-colors ${
                selectedSeller?.id === seller.id ? 'bg-gray-100' : ''
              }`}
              onClick={() => {
                setSelectedSeller(seller)
                setPaymentMethod('communitySeller')
              }}
            >
              <span>{seller.name}</span>
              <span className="text-sm text-gray-600">{seller.panyeroTokens} tokens</span>
            </button>
          ))}
        </div>
      )
    }

    return (
      <div className="grid grid-cols-2 gap-2">
        {paymentOptions[paymentCategory].map((option) => (
          <button
            key={option.id}
            className={`p-3 border rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-[#E0F2E9] transition-colors ${
              paymentMethod === option.id ? 'bg-[#E0F2E9]' : ''
            }`}
            onClick={() => setPaymentMethod(option.id)}
          >
            <option.icon className="w-6 h-6 text-gray-700" />
            <span className="text-xs text-gray-700">{option.name}</span>
          </button>
        ))}
      </div>
    )
  }

  const renderPaymentDetails = () => {
    if (!paymentMethod) return null

    if (paymentMethod === 'communitySeller' && selectedSeller) {
      return (
        <div className="bg-green-50 p-4 rounded-lg">
          <h4 className="font-semibold text-gray-800 mb-2">Community Seller Details</h4>
          <p className="text-sm text-green-600">Name: {selectedSeller.name}</p>
          <p className="text-sm text-green-600">Available Tokens: {selectedSeller.panyeroTokens}</p>
        </div>
      )
    }

    if (paymentMethod === 'gcash') {
      return (
        <div className="bg-green-50 p-4 rounded-lg">
          <h4 className="font-semibold text-gray-800 mb-2">GCash Payment Details</h4>
          <p className="text-sm text-green-600">Number: 0912345678</p>
          <p className="text-sm text-green-600">Name: Panyero Cruz</p>
        </div>
      )
    }

    // Add more payment details for other methods as needed

    return null
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md hover:shadow-lg transition-shadow">
        <h3 className="font-roboto font-semibold text-[#00A651] mb-4">Cash In</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-800 text-sm mb-2">Amount</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
              className="w-full p-2 border rounded-lg placeholder-gray-500"
              placeholder="Enter amount"
            />
          </div>
          <div>
            <label className="block text-gray-800 text-sm mb-2">Payment Category</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                className={`p-3 border rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-gray-100 transition-colors ${
                  paymentCategory === 'eWallet' ? 'bg-gray-100' : ''
                }`}
                onClick={() => {
                  setPaymentCategory('eWallet')
                  setPaymentMethod(null)
                  setSelectedSeller(null)
                }}
              >
                <Wallet className="w-6 h-6 text-gray-700" />
                <span className="text-xs text-gray-700">eWallet</span>
              </button>
              <button
                className={`p-3 border rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-gray-100 transition-colors ${
                  paymentCategory === 'bank' ? 'bg-gray-100' : ''
                }`}
                onClick={() => {
                  setPaymentCategory('bank')
                  setPaymentMethod(null)
                  setSelectedSeller(null)
                }}
              >
                <Building className="w-6 h-6 text-gray-700" />
                <span className="text-xs text-gray-700">Bank</span>
              </button>
              <button
                className={`p-3 border rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-gray-100 transition-colors ${
                  paymentCategory === 'communitySeller' ? 'bg-gray-100' : ''
                }`}
                onClick={() => {
                  setPaymentCategory('communitySeller')
                  setPaymentMethod(null)
                  setSelectedSeller(null)
                }}
              >
                <Users className="w-6 h-6 text-gray-700" />
                <span className="text-xs text-gray-700">Community</span>
              </button>
            </div>
          </div>
          {paymentCategory && (
            <div>
              <label className="block text-gray-800 text-sm mb-2">Payment Method</label>
              {renderPaymentOptions()}
            </div>
          )}
          {renderPaymentDetails()}
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 py-2 border border-[#00A651] text-[#00A651] rounded-lg hover:bg-[#E0F2E9] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleCashIn}
              className="flex-1 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008c44] transition-colors"
              disabled={!amount || !paymentMethod}
            >
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CashInModal

