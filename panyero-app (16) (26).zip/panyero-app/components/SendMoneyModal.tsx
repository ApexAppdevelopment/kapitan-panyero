import { useState, FC } from 'react'
import { db } from '../firebase'
import { collection, addDoc, serverTimestamp, updateDoc, doc, increment } from 'firebase/firestore'
import Image from 'next/image'
import { User, ChevronDown } from 'lucide-react'

interface SendMoneyModalProps {
  onClose: () => void
  balance: number
  onBalanceChange: (newBalance: number) => void
}

interface Recipient {
  id: string
  name: string
  phoneNumber: string
  avatarUrl: string
}

const recipients: Recipient[] = [
  { id: 'user1', name: 'John Doe', phoneNumber: '+63 912 345 6789', avatarUrl: '/placeholder.svg?height=40&width=40' },
  { id: 'user2', name: 'Jane Smith', phoneNumber: '+63 923 456 7890', avatarUrl: '/placeholder.svg?height=40&width=40' },
  { id: 'user3', name: 'Bob Johnson', phoneNumber: '+63 934 567 8901', avatarUrl: '/placeholder.svg?height=40&width=40' },
]

const SendMoneyModal: FC<SendMoneyModalProps> = ({ onClose, balance, onBalanceChange }) => {
  const [amount, setAmount] = useState<number | ''>('')
  const [selectedUser, setSelectedUser] = useState<Recipient | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [password, setPassword] = useState('')
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)

  const handleSendMoney = async () => {
    if (!selectedUser || amount === '' || !password) {
      setError('Please fill in all fields')
      return
    }
    if (parseFloat(amount.toString()) > balance) {
      setError('Insufficient balance')
      return
    }

    // Here you would typically verify the password with your backend
    // For this example, we'll use a dummy check
    if (password !== 'correctpassword') {
      setError('Incorrect password')
      return
    }

    try {
      const newBalance = balance - parseFloat(amount.toString())
      
      // Add transaction to Firestore
      await addDoc(collection(db, 'transactions'), {
        type: 'send',
        amount: parseFloat(amount.toString()),
        title: `Sent to ${selectedUser.name}`,
        timestamp: serverTimestamp(),
        recipientId: selectedUser.id,
      })

      // Update user's balance in Firestore
      const userRef = doc(db, 'users', 'currentUserId') // Replace 'currentUserId' with actual user ID
      await updateDoc(userRef, {
        balance: increment(-parseFloat(amount.toString()))
      })

      onBalanceChange(newBalance)
      onClose()
    } catch (error) {
      console.error('Error sending money:', error)
      setError('Failed to send money. Please try again.')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md hover:shadow-lg transition-shadow">
        <h3 className="font-roboto font-semibold text-gray-800 mb-4">Send Money</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-gray-800 mb-2">Select Recipient</label>
            <div className="relative">
              <button
                className="w-full p-2 border rounded-lg flex items-center justify-between focus:ring-2 focus:ring-[#00A651] focus:border-transparent"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                {selectedUser ? (
                  <div className="flex items-center">
                    <Image
                      src={selectedUser.avatarUrl}
                      alt={selectedUser.name}
                      width={24}
                      height={24}
                      className="rounded-full mr-2"
                    />
                    <span className="text-gray-800">{selectedUser.name}</span>
                  </div>
                ) : (
                  <span className="text-gray-500">Select a recipient</span>
                )}
                <ChevronDown className="w-5 h-5 text-gray-500" />
              </button>
              {isDropdownOpen && (
                <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg">
                  {recipients.map((recipient) => (
                    <div
                      key={recipient.id}
                      className="flex items-center p-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => {
                        setSelectedUser(recipient)
                        setIsDropdownOpen(false)
                      }}
                    >
                      <Image
                        src={recipient.avatarUrl}
                        alt={recipient.name}
                        width={24}
                        height={24}
                        className="rounded-full mr-2"
                      />
                      <div>
                        <div className="text-sm text-gray-800">{recipient.name}</div>
                        <div className="text-xs text-gray-500">{recipient.phoneNumber}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-800 mb-2">Amount</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent placeholder-gray-500 text-gray-800"
              placeholder="Enter amount"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-800 mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-[#00A651] focus:border-transparent placeholder-gray-500 text-gray-800"
              placeholder="Enter your password"
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 py-2 border border-[#00A651] text-[#00A651] rounded-lg hover:bg-[#E0F2E9] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSendMoney}
              className="flex-1 py-2 bg-[#00A651] text-white rounded-lg hover:bg-[#008c44] transition-colors"
              disabled={!selectedUser || amount === '' || !password}
            >
              Send Money
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SendMoneyModal

