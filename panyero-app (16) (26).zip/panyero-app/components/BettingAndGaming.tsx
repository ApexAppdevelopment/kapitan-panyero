import { FC } from 'react'
import { WalletCardsIcon as Cards, Dice1Icon as Dice, ShoppingBasketIcon as Basketball, DogIcon as Horse } from 'lucide-react'

const categories = [
  {
    title: 'Live Casino',
    icon: Cards,
    games: [
      'Blackjack', 'Roulette', 'Baccarat', 'Poker', 'Sic Bo',
      'Dragon Tiger', 'Craps', 'Game Shows', 'Keno', 'Monopoly',
      'Deal or No Deal', 'Mega Ball', 'Andar Bahar', 'Teen Patti', 'Football Studio',
      'Casino Hold\'em', 'Three Card Poker', 'Caribbean Stud', 'Ultimate Texas Hold\'em', 'Lightning Dice'
    ]
  },
  {
    title: 'Lottery',
    icon: Dice,
    games: [
      'Lotto', 'Powerball', 'Mega Millions', 'EuroMillions', 'Keno',
      'Scratch-Offs', 'Daily Draws', 'Pick 3/4', 'Raffles', 'Bonus Ball',
      'Jackpot', 'Multi-State', 'Instant Win', 'Progressive', 'Sports Lottery',
      'Charity', 'Online', 'Syndicate', 'Number Games', 'Themed'
    ]
  },
  {
    title: 'NBA Betting',
    icon: Basketball,
    games: [
      'Moneyline', 'Point Spread', 'Over/Under', 'Parlay', 'Prop Bets',
      'Futures', 'Live/In-Game', 'Quarter/Half', 'Teaser', 'Round Robin',
      'Player Performance', 'Team Totals', 'Winning Margin', 'First Basket', 'Exact Score',
      'Double Result', 'Series Bets', 'Season Win Totals', 'Awards Bets'
    ]
  },
  {
    title: 'Filipino Games',
    icon: Horse,
    games: [
      'Color Game', 'Horse Racing', 'Sabong', 'Jueteng', 'Bingo',
      'Pusoy', 'Tong-its', 'Lucky 9', 'Pula Puti', 'Sakla',
      'Hantak', 'Cara y Cruz', 'Mahjong', 'Sungka', 'Beto-Beto',
      'Pakito', 'Pares-Pares', 'Ending', 'Last Two', 'Swertres'
    ]
  }
]

const BettingAndGaming: FC = () => {
  return (
    <div className="bg-white rounded-xl shadow-md p-6 mb-6">
      <h2 className="text-2xl font-bold text-[#00A651] mb-4">Betting & Gaming</h2>
      <div className="space-y-6">
        {categories.map((category, index) => (
          <div key={index}>
            <div className="flex items-center mb-2">
              <category.icon className="w-6 h-6 text-[#00A651] mr-2" />
              <h3 className="text-lg font-semibold">{category.title}</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {category.games.map((game, gameIndex) => (
                <div key={gameIndex} className="bg-gray-100 rounded-lg p-2 text-center text-sm hover:bg-gray-200 transition-colors cursor-pointer">
                  {game}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default BettingAndGaming

