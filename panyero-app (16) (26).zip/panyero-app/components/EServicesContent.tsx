'use client'

import { FC, useEffect, useState } from 'react'
import Image from 'next/image'
import { X } from 'lucide-react'

interface Service {
  id: string
  name: string
  url: string
  iconUrl: string
}

interface Props {
  searchTerm: string
}

const EServicesContent: FC<Props> = ({ searchTerm }) => {
  const [services, setServices] = useState<Service[]>([])
  const [filteredServices, setFilteredServices] = useState<Service[]>([])
  const [selectedService, setSelectedService] = useState<Service | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await fetch('https://panyero.website/wallet-app/knowledge-panyeroapp.json')
        const data = await response.json()
        const serviceList = Object.entries(data).map(([key, value]: [string, any]) => ({
          id: key,
          name: (value.title || '').slice(0, 8),
          url: value.url || 'https://panyero.website/movie',
          iconUrl: (value.icon && typeof value.icon === 'string' && value.icon.startsWith('http')) 
            ? value.icon 
            : `https://panyero.website/wallet-app/assets/${value.icon || 'default-icon.png'}`
        }))
        setServices(serviceList)
        setFilteredServices(serviceList)
      } catch (error) {
        console.error('Error fetching services:', error)
        setError('Failed to load services. Please try again later.')
      }
    }

    fetchServices()
  }, [])

  useEffect(() => {
    if (searchTerm) {
      const filtered = services.filter(service =>
        service.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
      setFilteredServices(filtered)
    } else {
      setFilteredServices(services)
    }
  }, [searchTerm, services])

  const handleServiceClick = (service: Service) => {
    setSelectedService(service)
  }

  const handleCloseEmbed = () => {
    setSelectedService(null)
  }

  return (
    <div className="space-y-6">
      {error ? (
        <div className="text-red-500 text-center">{error}</div>
      ) : (
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-4 p-4 bg-white rounded-xl shadow">
          {filteredServices.map((service) => (
            <button
              key={service.id}
              className="flex flex-col items-center justify-center p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer min-w-[48px] min-h-[48px]"
              onClick={() => handleServiceClick(service)}
            >
              <div className="w-10 h-10 mb-2">
                <Image
                  src={service.iconUrl}
                  alt={service.name}
                  width={40}
                  height={40}
                  className="object-contain"
                />
              </div>
              <span className="text-xs font-medium text-center truncate w-full">{service.name}</span>
            </button>
          ))}
        </div>
      )}
      {selectedService && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col">
          <div className="flex justify-end p-4">
            <button
              onClick={handleCloseEmbed}
              className="text-white hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <iframe
            src={selectedService.url}
            className="flex-1 w-full"
            style={{ border: 'none' }}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; microphone"
            allowFullScreen
          />
        </div>
      )}
    </div>
  )
}

export default EServicesContent

