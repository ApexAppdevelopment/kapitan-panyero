'use client'

import { FC } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, CreditCard, QrCode, Ship, User } from 'lucide-react'

const NavigationBar: FC = () => {
  const pathname = usePathname()

  const navItems = [
    { icon: Home, label: 'Home', href: '/' },
    { icon: CreditCard, label: 'E-Services', href: '/eservices' },
    { icon: QrCode, label: 'Scan', href: '/scan' },
    { icon: Ship, label: 'Maritime', href: '/maritime' },
    { icon: User, label: 'Profile', href: '/profile' },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#EFEFEF] p-4 shadow-lg">
      <div className="flex justify-around items-center">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center ${
              item.href === '/scan' ? '-mt-6' : ''
            }`}
          >
            <div
              className={`${
                item.href === '/scan' ? 'gradient-bg rounded-full p-4 shadow-lg' : 'p-2'
              }`}
            >
              <item.icon
                className={`${
                  pathname === item.href ? 'text-[#00A651]' : 'text-[#1E1E1E]'
                } ${
                  item.href === '/scan' ? 'h-8 w-8 text-white' : 'h-6 w-6'
                }`}
              />
            </div>
            <span className={`text-xs mt-1 ${pathname === item.href ? 'text-[#00A651]' : 'text-[#1E1E1E]'}`}>
              {item.label}
            </span>
          </Link>
        ))}
      </div>
    </nav>
  )
}

export default NavigationBar

