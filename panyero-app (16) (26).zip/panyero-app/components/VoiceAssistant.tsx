'use client'

import { useState, useEffect } from 'react'
import { X } from 'lucide-react'

const VoiceAssistant = () => {
  const [isClicked, setIsClicked] = useState(false)
  const [showEmbed, setShowEmbed] = useState(false)

  const handleClick = async () => {
    setIsClicked(true)
    
    try {
      // Request microphone permission
      await navigator.mediaDevices.getUserMedia({ audio: true })
      
      // Request clipboard permission
      await navigator.permissions.query({ name: 'clipboard-write' as PermissionName })
      
      // Show the embedded interface
      setShowEmbed(true)
    } catch (error) {
      console.error('Error requesting permissions:', error)
    }
    
    setIsClicked(false)
  }

  useEffect(() => {
    if (showEmbed) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'auto'
    }

    return () => {
      document.body.style.overflow = 'auto'
    }
  }, [showEmbed])

  return (
    <>
      <div 
        className="fixed bottom-24 right-4 cursor-pointer hover:scale-110 transition-transform z-40"
        style={{ transform: 'translateY(-25px)' }}
        onClick={handleClick}
      >
        <img 
          src="https://panyero.website/wallet-app/assets/voice.gif"
          alt="Voice assistant icon" 
          className="w-[30px] h-[30px] rounded-full shadow-lg"
          style={{ pointerEvents: isClicked ? 'none' : 'auto' }}
        />
      </div>

      {showEmbed && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-5">
          <div className="relative w-full h-full max-w-[calc(100%-40px)] max-h-[calc(100%-100px)] bg-white rounded-lg overflow-hidden">
            <div className="absolute top-2 right-2 z-10">
              <button 
                onClick={() => setShowEmbed(false)}
                className="text-gray-600 hover:text-gray-800 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <iframe
              src="https://panyero.website/niyero/"
              className="w-full h-full"
              style={{ border: 'none' }}
              allow="microphone; clipboard-write"
            />
          </div>
        </div>
      )}
    </>
  )
}

export default VoiceAssistant

