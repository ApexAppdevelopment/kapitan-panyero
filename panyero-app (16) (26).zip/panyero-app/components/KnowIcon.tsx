import { Book } from 'lucide-react'

export default function KnowIcon() {
  return (
    <div className="flex flex-col items-center justify-center p-4 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer">
      <Book className="w-8 h-8 text-[#00A651] mb-2" />
      <span className="text-xs font-medium text-center">Knowbase</span>
    </div>
  )
}

