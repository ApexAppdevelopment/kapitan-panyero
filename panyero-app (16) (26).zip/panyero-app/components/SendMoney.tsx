'use client'

import { ArrowLeft, User2 } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'

export default function SendMoney() {
  const [amount, setAmount] = useState('')
  const [recipient, setRecipient] = useState('')
  const [note, setNote] = useState('')
  const [includeSignature, setIncludeSignature] = useState(true)

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-4">
          <Link href="/" className="p-2">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-medium">Send money</h1>
        </div>
        <span className="text-sm text-gray-500">1/2</span>
      </div>

      {/* Favorites Section */}
      <div className="px-4 mb-8">
        <h2 className="text-gray-500 font-medium mb-4">MY FAVORITES</h2>
        <div className="border-2 border-dashed border-gray-200 rounded-xl p-4 text-center text-gray-400">
          <User2 className="w-8 h-8 mx-auto mb-2" />
          <p>Complete a transaction to add it to your favorites</p>
        </div>
      </div>

      {/* Form */}
      <div className="px-4 space-y-6">
        <div>
          <label className="block text-[#00A651] mb-1">Recipient</label>
          <input
            type="text"
            placeholder="ex. Jan, @jan, or 09161234567"
            className="maya-input"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
          />
        </div>

        <div>
          <label className="block text-[#00A651] mb-1">Amount</label>
          <input
            type="number"
            placeholder="Enter amount"
            className="maya-input"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <p className="text-gray-500 mt-2">You have ₱351.70 in your wallet.</p>
        </div>

        <div>
          <label className="block text-[#00A651] mb-1">Note (Optional)</label>
          <input
            type="text"
            placeholder="Add a note"
            className="maya-input"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>

        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={includeSignature}
            onChange={(e) => setIncludeSignature(e.target.checked)}
            className="rounded border-gray-300 text-[#00A651] focus:ring-[#00A651]"
          />
          <span className="text-gray-600">Include signature: from Juan dela Cruz</span>
        </label>

        <div className="mt-8">
          <h3 className="text-xl font-medium mb-4">Personalize your message</h3>
          <div className="flex gap-4">
            <button className="flex-1 p-4 rounded-xl border border-gray-200 text-center">
              Add a GIF
            </button>
            <button className="flex-1 p-4 rounded-xl border border-gray-200 text-center text-gray-400">
              Add a Theme
            </button>
          </div>
        </div>
      </div>

      {/* Continue Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4">
        <button 
          className="maya-button"
          disabled={!recipient || !amount}
        >
          Continue
        </button>
      </div>
    </div>
  )
}

