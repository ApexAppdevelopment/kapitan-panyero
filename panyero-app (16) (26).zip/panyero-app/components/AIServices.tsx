import { FC } from 'react'
import { Ship, GraduationCap, Plane, ShoppingCart, Book, PiggyBank, School, Building, Map, Store, Heart, Flower2, Stethoscope, Zap, BrushIcon as Broom, Shield, ChefHat, Mountain, Briefcase, Languages } from 'lucide-react'
import Image from 'next/image'

const aiServices = [
  { icon: Ship, title: 'Kapita', name: 'Kapitan Niyero' },
  { icon: GraduationCap, title: 'Ate Ed', name: 'Ate Edu' },
  { icon: Plane, title: 'Kuya J', name: 'Kuya Juan' },
  { icon: ShoppingCart, title: 'Aling', name: 'Aling Sugod' },
  { icon: Book, title: 'Lola T', name: 'Lola Tales' },
  { icon: PiggyBank, title: 'Tito S', name: 'Tito Saver' },
  { icon: School, title: 'Guro', name: 'Guro AI' },
  { icon: Building, title: 'Brgy', name: 'Barangay Bot' },
  { icon: Map, title: 'Biyahe', name: 'Biyahero Buddy' },
  { icon: Store, title: 'Tatay', name: 'Tatay Barya' },
  { icon: Heart, title: 'Nanay', name: 'Nanay Kalinga' },
  { icon: Flower2, title: 'Mang T', name: 'Mang Tanim' },
  { icon: Stethoscope, title: 'Dr. A', name: 'Dr. Albularyo' },
  { icon: Zap, title: 'Kuya K', name: 'Kuya Kuryente' },
  { icon: Broom, title: 'Ate K', name: 'Ate Kasambahay' },
  { icon: Shield, title: 'Tito B', name: 'Tito Bantay' },
  { icon: ChefHat, title: 'Chef P', name: 'Chef Pinoy' },
  { icon: Mountain, title: 'Lakwat', name: 'Lakwatsera AI' },
  { icon: Briefcase, title: 'Kasosy', name: 'Kasosyo AI' },
  { icon: Languages, title: 'Tagalo', name: 'Tagalog Tutor Bot' },
]

const AIServices: FC = () => {
  return (
    <div className="bg-white rounded-xl shadow-md p-6 mb-6">
      <h2 className="text-2xl font-bold text-[#00A651] mb-4">AI Services</h2>
      <div className="grid grid-cols-4 gap-4">
        {aiServices.map((service, index) => (
          <div key={index} className="flex flex-col items-center justify-center p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer">
            <service.icon className="w-8 h-8 text-[#00A651] mb-2" />
            <span className="text-xs font-medium text-center">{service.title}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default AIServices

