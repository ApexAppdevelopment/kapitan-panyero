import { FC } from 'react'
import { Bot } from 'lucide-react'

const KapitanNiyero: FC = () => {
  return (
    <div className="gradient-bg p-6 rounded-xl shadow-md mx-4 mb-6 text-white">
      <div className="flex items-center gap-2 mb-2">
        <Bot size={24} />
        <h2 className="font-roboto font-semibold">Kapitan Niyero</h2>
      </div>
      <p className="text-sm mb-3">How can I assist you today, ka-Panyero?</p>
      <div className="flex gap-2">
        <button className="bg-white/20 px-3 py-1 rounded-full text-sm hover:bg-white/30 transition-colors">Weather Update</button>
        <button className="bg-white/20 px-3 py-1 rounded-full text-sm hover:bg-white/30 transition-colors">Route Check</button>
      </div>
    </div>
  )
}

export default KapitanNiyero

