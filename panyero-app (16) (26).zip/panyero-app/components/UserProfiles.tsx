'use client'

import { FC, useState } from 'react'
import Image from 'next/image'

interface User {
  id: string
  name: string
  photoURL: string
}

const UserProfiles: FC = () => {
  const [users] = useState<User[]>([
    {
      id: '1',
      name: 'John Doe',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '2',
      name: 'Mike Smith',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '3',
      name: 'Alex Johnson',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '4',
      name: 'Chris Wilson',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '5',
      name: 'Sam Brown',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '6',
      name: 'David Lee',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '7',
      name: 'James Taylor',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    },
    {
      id: '8',
      name: 'Ryan Garcia',
      photoURL: 'https://www.pngkey.com/png/full/114-1149878_setting-user-avatar-in-specific-size-without-breaking.png'
    }
  ]);

  return (
    <div className="overflow-x-auto mb-6">
      <div className="flex gap-4 p-2">
        {users.map((user) => (
          <div key={user.id} className="flex-shrink-0 text-center cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition-colors">
            <div className="w-16 h-16 rounded-full overflow-hidden mb-1">
              <Image
                src={user.photoURL}
                alt={user.name}
                width={64}
                height={64}
                className="w-full h-full object-cover"
                priority
              />
            </div>
            <p className="text-xs text-center truncate w-16">{user.name}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default UserProfiles

