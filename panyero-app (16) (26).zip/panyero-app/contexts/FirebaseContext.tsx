'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { initializeApp } from 'firebase/app'
import { getFirestore, collection, getDocs, addDoc, DocumentData, serverTimestamp } from 'firebase/firestore'

const firebaseConfig = {
  // Replace with your Firebase config
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
}

const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

type FirebaseContextType = {
  users: DocumentData[]
  transactions: DocumentData[]
  fetchUsers: () => Promise<void>
  fetchTransactions: () => Promise<void>
  addTransaction: (transaction: Omit<Transaction, 'id' | 'timestamp'>) => Promise<void>
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined)

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useState<DocumentData[]>([])
  const [transactions, setTransactions] = useState<DocumentData[]>([])

  const fetchUsers = async () => {
    const usersCollection = collection(db, 'users')
    const userSnapshot = await getDocs(usersCollection)
    const userList = userSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    setUsers(userList)
  }

  const fetchTransactions = async () => {
    const transactionsCollection = collection(db, 'transactions')
    const transactionSnapshot = await getDocs(transactionsCollection)
    const transactionList = transactionSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    setTransactions(transactionList)
  }

  const addTransaction = async (transaction: Omit<Transaction, 'id' | 'timestamp'>) => {
    const transactionsCollection = collection(db, 'transactions')
    await addDoc(transactionsCollection, { ...transaction, timestamp: serverTimestamp() })
    await fetchTransactions()
  }

  useEffect(() => {
    fetchUsers()
    fetchTransactions()
  }, [])

  return (
    <FirebaseContext.Provider value={{ users, transactions, fetchUsers, fetchTransactions, addTransaction }}>
      {children}
    </FirebaseContext.Provider>
  )
}

export const useFirebase = () => {
  const context = useContext(FirebaseContext)
  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider')
  }
  return context
}

